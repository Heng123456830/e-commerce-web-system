Admin login page:admin_login.php

User page login:login.php

Staff:(email:heng123@exmaple.com,password:12345678)

Can:Add, edit, and delete products,View reports,Update order statuses.

Cannot:Access the profile page.,Add to cart, checkout, make payments, place orders, or view orders before registration as a customer.

Perform any actions beyond the admin interface features mentioned above.

Manager:(email:tpr@gmail.com ,password:12345678)

Can:Access all admin pages (with full administrative privileges).

Cannot:Access profile-related actions (add to cart, checkout, make payment, place orders, view orders) without being registered as a customer.

The same restrictions apply as the staff role in terms of customer actions.

Customer/Member:(email:reams@bluevystore.com , password:12345678)

Can:Login and access the user page,View product details.

Cannot:Access admin pages (e.g., adding/editing products, viewing reports, etc.).Perform administrative actions like updating orders or managing products.

Admin Account:Both staff and manager can log in as admin to view product details or perform admin-level tasks, but they cannot interact as customers (e.g., add to cart, checkout, make payments, etc.) unless they are registered as a customer.

